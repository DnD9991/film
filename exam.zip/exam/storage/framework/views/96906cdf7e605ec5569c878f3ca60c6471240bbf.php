<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row">
            <h1>Submit a film</h1>
            <form action="/films" method="post">
                <?php if($errors->any()): ?>
                    <div class="alert alert-danger" role="alert">
                        Please fix the following errors
                    </div>
                <?php endif; ?>

                <?php echo csrf_field(); ?>

                <div class="form-group">
                    <label for="Name">Name</label>
                    <input type="text" class="form-control" id="Name" name="Name" placeholder="Name" >
                </div>
                <div class="form-group">
                    <label for="Description">Description</label>
                    <textarea class="form-control" id="Description" name="Description" placeholder="Description"></textarea>
                </div>
                <div class="form-group">
                    <label for="RealeaseDate">RealeaseDate</label>
                    <input type="text" class="form-control" id="RealeaseDate" name="RealeaseDate" placeholder="RealeaseDate" >
                </div>
                <div class="form-group">
                    <label for="Rating">Rating</label>
                    <input type="text" class="form-control" id="Rating" name="Rating" placeholder="Rating">
                </div><div class="form-group">
                    <label for="TicketPrice">Ticket Price</label>
                    <input type="text" class="form-control" id="TicketPrice" name="TicketPrice" placeholder="Ticket Price">
                </div><div class="form-group">
                    <label for="Country">Country</label>
                    <input type="text" class="form-control" id="Country" name="Country" placeholder="Country">
                </div><div class="form-group">
                    <label for="Genre">Genre</label>
                    <input type="text" class="form-control" id="Genre" name="Genre" placeholder="Genre">
                </div>
                <!--<div class="form-group">
                    <label for="filmimageid">Film Image</label>
                    <input name="image" type="file" id="filmimageid" class="inputfile">
                </div>-->
                <a href="http://exam.test/films"><button type="submit" class="btn btn-primary">Submit</button></a>
            </form>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>