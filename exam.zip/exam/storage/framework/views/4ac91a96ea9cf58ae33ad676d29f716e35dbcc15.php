<?php $__env->startSection('content'); ?>
 
    <div class="card" style="width: 270px;margin: 5px">
        <div class="card-block">
            <h3 class="card-title">Films</h3>
                <?php $__currentLoopData = $film; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $link): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                <p class="film">
                        <a href="http://exam.test/films/<?php echo e($link->id); ?>"><?php echo e($link->Name); ?></a>
                </p>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <a href="http://exam.test/films/create" class="btn btn-primary">Submit a Film</a>

        </div>
    </div>
 <?php $__env->stopSection(); ?>


                    
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>