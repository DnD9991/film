<?php

use Faker\Generator as Faker;

/* @var Illuminate\Database\Eloquent\Factory $factory */

$factory->define(App\Link::class, function (Faker $faker) {
    return [
        'Name' => substr($faker->sentence(2), 0, -1),
        'Description' => substr($faker->sentence(2), 0, -1),
        'RealeaseDate' => $faker->date,
        'Rating' => $faker->randomFloat(1, 0, 5),
        'TicketPrice' => $faker->randomFloat(1, 0, 50),
		'Country' => $faker->country,
        'Genre' => substr($faker->sentence(2), 0, -1),

    ];
});
