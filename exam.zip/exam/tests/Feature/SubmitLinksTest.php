<?php

namespace Tests\Feature;

/*use Tests\TestCase;
use Illuminate\Foundation\Testing\WithFaker;
use Illuminate\Foundation\Testing\RefreshDatabase;*/

use Illuminate\Validation\ValidationException;
use Tests\TestCase;
use Illuminate\Foundation\Testing\RefreshDatabase;

class SubmitLinksTest extends TestCase
{
	use RefreshDatabase;

    /**
     * A basic test example.
     *
     * @return void
     */
    /** @test */
	function guest_can_submit_a_new_link()
	    {
	        $response = $this->post('/submit', [
	            'Name' => 'ExampleName',
	            'url' => 'http://example.com',
	            'RealeaseDate' => '14/04/1987',
		        'Rating' => '4.5',
		        'TicketPrice' => '16.5',
		        'Country' => 'Singapore',
				'Genre' => 'Comedy',
	        ]);

	        $this->assertDatabaseHas('links', [
	            'Name' => 'ExampleName'
	        ]);

	        $response
	            ->assertStatus(302)
	            ->assertHeader('Location', url('/'));

	        $this
	            ->get('/')
	            ->assertSee('ExampleName');
	    }
	/** @test */
	function link_is_not_created_if_validation_fails()	
	{
	    $response = $this->post('/submit');

	    $response->assertSessionHasErrors(['Name', 'url', 'RealeaseDate', 'Rating', 'TicketPrice', 'Country', 'Genre']);
	}

	/** @test */
	function link_is_not_created_with_an_invalid_url()
	{
	    $this->withoutExceptionHandling();

	    $cases = ['//invalid-url.com', '/invalid-url', 'foo.com'];

	    foreach ($cases as $case) {
	        try {
	            $response = $this->post('/submit', [
	                'Name' => 'ExampleName',
	                'url' => $case,
		            'RealeaseDate' => '14/04/1987',
			        'Rating' => '4.5',
			        'TicketPrice' => '16.5',
			        'Country' => 'Singapore',
					'Genre' => 'Comedy',
	            ]);
	        } catch (ValidationException $e) {
	            $this->assertEquals(
	                'The url format is invalid.',
	                $e->validator->errors()->first('url')
	            );
	            continue;
	        }

	        $this->fail("The URL $case passed validation when it should have failed.");
	    }
	}
	/** @test */
	function max_length_fails_when_too_long()
	{
	    $this->withoutExceptionHandling();

	    $Name = str_repeat('a', 256);
	    $RealeaseDate = str_repeat('a', 256);
	    $Rating = str_repeat('a', 256);
	    $TicketPrice = str_repeat('a', 256);
	    $Country = str_repeat('a', 256);
	    $Genre = str_repeat('a', 256);
		$url = 'http://';
	    $url .= str_repeat('a', 256 - strlen($url));

	    try {
	        $this->post('/submit', compact('Name', 'url', 'RealeaseDate', 'Rating', 'TicketPrice', 'Country', 'Genre'));
	    } catch(ValidationException $e) {
	        $this->assertEquals(
	            'The name may not be greater than 255 characters.',
	            $e->validator->errors()->first('Name')
	        );

	        $this->assertEquals(
	            'The url may not be greater than 255 characters.',
	            $e->validator->errors()->first('url')
	        );

	        $this->assertEquals(
	            'The realease date may not be greater than 255 characters.',
	            $e->validator->errors()->first('RealeaseDate')
	        );
			$this->assertEquals(
	            'The rating may not be greater than 255 characters.',
	            $e->validator->errors()->first('Rating')
	        );
	        $this->assertEquals(
	            'The ticket price may not be greater than 255 characters.',
	            $e->validator->errors()->first('TicketPrice')
	        );$this->assertEquals(
	            'The country may not be greater than 255 characters.',
	            $e->validator->errors()->first('Country')
	        );$this->assertEquals(
	            'The genre may not be greater than 255 characters.',
	            $e->validator->errors()->first('Genre')
	        );
	        return;
	    }

	    $this->fail('Max length should trigger a ValidationException');
	}
	/** @test */
	function max_length_succeeds_when_under_max()
	{
	    $url = 'http://';
	    $url .= str_repeat('a', 255 - strlen($url));

	    $data = [
	        'Name' => str_repeat('a', 255),
	        'url' => $url,
	        'RealeaseDate' => str_repeat('a', 255),
	        'Rating' => str_repeat('a', 255),
	        'TicketPrice' => str_repeat('a', 255),
	        'Country' => str_repeat('a', 255),
	        'Genre' => str_repeat('a', 255),

	    ];

	    $this->post('/submit', $data);

	    $this->assertDatabaseHas('links', $data);
	}
    public function testExample()
    {
        $this->assertTrue(true);
    }
}
