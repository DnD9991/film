<?php
 
namespace App\Http\Controllers;
 
use Illuminate\Http\Request;
use App\Link;
use Storage;
 
class FilmsController extends Controller
{
    public function index()
    {
        $films = \App\Link::all();
        return view('films.index', ['film' => $films]);
    }
    
    public function show(Link $id)
    {
        return view('films.show', ['film' => $id]);
    }
    
    public function create()
    {
        return view('films.create');
    }

    public function store()
    {
        
        $film = new \App\Link;;
        	
        $film->Name = request('Name');
        $film->Description = request('Description');
        $film->RealeaseDate = request('RealeaseDate');
        $film->Rating = request('Rating');
        $film->TicketPrice = request('TicketPrice');
        $film->Country = request('Country');
        $film->Genre = request('Genre');        
        //$film->Image = request()->file('Image')->storeImage();


        $film->save();
        $films = \App\Link::all();
        return view('films.index', ['film' => $films]);
    }
    /*public function storeImage() {
    return Storage::putFile('public/Images',
               request()->file('uploadedFile')
           );
    }*/
     
}
