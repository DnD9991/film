<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

/*Route::get('/', function () {
      $exam = \App\Link::all();
       return view('welcome', ['exam' => $exam]);

});*/
Route::get('/', 'FilmsController@index');

Auth::routes();

Route::get('/home', 'HomeController@index')->name('home');

Route::get('films', 'FilmsController@index');
 
Route::get('films/create', 'FilmsController@create'); 

Route::get('films/{id}', 'FilmsController@show');

Route::post('films', 'FilmsController@store');




Route::get('/submit', function () {
    return view('submit');
});

use Illuminate\Http\Request;

Route::post('/submit', function (Request $request) {
    $data = $request->validate([
        'Name' => 'required|max:255',
        'url' => 'required|url|max:255',
        'RealeaseDate' => 'required|max:255',
        'Rating' => 'required|max:255',
        'TicketPrice' => 'required|max:255',
		'Country' => 'required|max:255',
        'Genre' => 'required|max:255',

    ]);

    //$link = tap(new App\Link($data))->save();
	$link = new \App\Link;
	$link->Name = $data['Name'];
	$link->url = $data['url'];

	//$link->url = 'http://'+$data['Name']+'.test';
	$link->RealeaseDate = $data['RealeaseDate'];
    $link->Rating = $data['Rating'];
	$link->TicketPrice = $data['TicketPrice'];
	$link->Country = $data['Country'];
	$link->Genre = $data['Genre'];

	$link->save();
return redirect('/');
});
