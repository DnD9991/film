@extends('layouts.app')
@section('content')
 
    <div class="card" style="width: 270px;margin: 5px">
        <div class="card-block">
            <h3 class="card-title">Films</h3>
                @foreach ($film as $link)

                <p class="film">
                        <a href="http://exam.test/films/{{ $link->id }}">{{ $link->Name }}</a>
                </p>
                @endforeach
            <a href="http://exam.test/films/create" class="btn btn-primary">Submit a Film</a>

        </div>
    </div>
 @endsection


                    