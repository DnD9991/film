<?php $__env->startSection('content'); ?>
 
    <div class="card" style="width: 270px;margin: 5px">
        
        <div class="card-block">
            <h3 class="card-title"><?php echo e($film->Name); ?></h3>
            <p class="card-text">Description: <?php echo e($film->Description); ?></p>
            <p class="card-text">Release Date: <?php echo e($film->RealeaseDate); ?></p>
            <p class="card-text">Rating: <?php echo e($film->Rating); ?></p>
            <p class="card-text">Ticket price: <?php echo e($film->TicketPrice); ?></p>
            <p class="card-text">Country: <?php echo e($film->Country); ?></p>
            <p class="card-text">Genre: <?php echo e($film->Genre); ?></p>
            <a href="/films" class="btn btn-primary">List Films</a>
        </div>
    </div>
 
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>