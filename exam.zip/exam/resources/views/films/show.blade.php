@extends('layouts.app')
@section('content')
 
    <div class="card" style="width: 270px;margin: 5px">
        
        <div class="card-block">
            <h3 class="card-title">{{ $film->Name }}</h3>
            <p class="card-text">Description: {{ $film->Description }}</p>
            <p class="card-text">Release Date: {{ $film->RealeaseDate }}</p>
            <p class="card-text">Rating: {{ $film->Rating }}</p>
            <p class="card-text">Ticket price: {{ $film->TicketPrice }}</p>
            <p class="card-text">Country: {{ $film->Country }}</p>
            <p class="card-text">Genre: {{ $film->Genre }}</p>
            <a href="/films" class="btn btn-primary">List Films</a>
        </div>
    </div>
 
@endsection